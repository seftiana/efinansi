<?php

$sql['get_jenis_biaya_id'] = "
SELECT
  `coaJenisBiayaKodeId` AS id
FROM `finansi_coa_jenis_biaya`
";