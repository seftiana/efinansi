var gtfwSubAccount =
{
   '.subaccount' : function (Obj)
   {
      $(Obj).mask("99-99-99-99-99-99-99");
   }
}

Behaviour.register(gtfwSubAccount);
