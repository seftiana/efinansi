/**
Copyright 2008 PT. Gamatechno Indonesia.
gamatechno.com Javascript Loader
Revision: 1.2 $
**/

document.writeln("<script type='text/javascript' src='js/vendor/jquery.ui/jquery-ui.min.js'></script>");
document.writeln("<script type='text/javascript' src='js/Base.js'></script>");
document.writeln("<script type='text/javascript' src='js/jtools.js'></script>");
document.writeln("<script type='text/javascript' src='js/upload_helper.js'></script>");
document.writeln("<script type='text/javascript' src='main/lib/js/ajax.js'></script>");
document.writeln("<script type='text/javascript' src='js/gtfw_ajax.js'></script>");
document.writeln("<script type='text/javascript' src='js/advajax_helper.js'></script>");
document.writeln("<script type='text/javascript' src='js/advajax.js'></script>");
document.writeln("<script type='text/javascript' src='js/xhr.rule.js'></script>");
document.writeln("<script type='text/javascript' src='js/xhr.reset.js'></script>");
document.writeln("<script type='text/javascript' src='js/gValidation.js'></script>");
document.writeln("<script type='text/javascript' src='js/gValidationNumber.js'></script>");
document.writeln("<script type='text/javascript' src='js/gValidationFloat.js'></script>");
document.writeln("<script type='text/javascript' src='js/popup.js'></script>");
document.writeln("<script type='text/javascript' src='js/janime.js'></script>");
document.writeln("<script type='text/javascript' src='js/jstable.js'></script>");
document.writeln("<script type='text/javascript' src='js/vendor/typeahead.js'></script>");
document.writeln("<script type='text/javascript' src='js/jqueryFileTree/jqueryFileTree.js'></script>");
document.writeln("<script type='text/javascript' src='js/dtree/dtree.js'></script>");
document.writeln("<script type='text/javascript' src='js/vendor/jquery.inputmask.js'></script>");
document.writeln("<script type='text/javascript' src='js/vendor/custom-js.js'></script>");
document.writeln("<script type='text/javascript' src='js/jqueryTableTree/jquery.lazyTreeTable.js'></script>");

document.writeln("<script type='text/javascript' src='js/nominalTerbilang.js'></script>");

/**
 * dhtmlx
 */
document.writeln("<script type='text/javascript' src='js/dhtmlx/dhtmlxtree/dhtmlxtree.js'></script>");
document.writeln("<script type='text/javascript' src='js/jquery.cookie.js'></script>");

// document.writeln("<script type='text/javascript' src='main/lib/editarea/edit_area/edit_area_full.js'></script>");
// document.writeln("<script type='text/javascript' src='main/lib/js/form-submit.js'></script>");
// document.writeln("<script type='text/javascript' src='js/jquery.js'></script>");
// document.writeln("<script type='text/javascript' src='js/ui.core.js'></script>");
// document.writeln("<script type='text/javascript' src='js/ui.draggable.js'></script>");
// document.writeln("<script type='text/javascript' src='js/balloon.js'></script>");
// document.writeln("<script type='text/javascript' src='js/simple_validator.js'></script>");
// document.writeln("<script type='text/javascript' src='js/FormHelper.js'></script>");
// document.writeln("<script type='text/javascript' src='js/a_sia_common.js'></script>");
// document.writeln("<script type='text/javascript' src='js/terbilang.js'></script>");
// document.writeln("<script type='text/javascript' src='js/confirmDelete.js'></script>");
// document.writeln("<script type='text/javascript' src='js/numeric/numericText.js'></script>");
// document.writeln("<script type='text/javascript' src='js/window.js'></script>");
// document.writeln("<script type='text/javascript' src='js/notify.js'></script>");
// document.writeln("<script type='text/javascript' src='js/table.rule.js'></script>");
// document.writeln("<script type='text/javascript' src='js/tooltip.rule.js'></script>");
// document.writeln("<script type='text/javascript' src='js/jquery.maskedinput-1.3.min.js'></script>");
// document.writeln("<script type='text/javascript' src='js/gtfwSubAccount.js'></script>");

// document.writeln("<script type='text/javascript' src='js/jqueryTableTree/jquery.lazyTreeTable.js'></script>");
// document.writeln("<script type='text/javascript' src='js/jquery.treeTable.js'></script>");